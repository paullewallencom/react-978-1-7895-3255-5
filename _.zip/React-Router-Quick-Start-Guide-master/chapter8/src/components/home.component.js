import React from 'react';

const Home = () => <div> In Home </div>

export default Home;