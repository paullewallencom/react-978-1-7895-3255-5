export const ROUTES = [{
    path: '/shopping-cart'
}]