import React from 'react';
// import { Route } from 'react-router-dom';

export const DashboardComponent = ({ match }) => (

    <div className="dashboard">
        Inside Dashboard route
    </div>
)