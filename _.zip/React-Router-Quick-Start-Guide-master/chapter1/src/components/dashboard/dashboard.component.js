import React from 'react';

export const DashboardComponent = () => (
    <div className="dashboard">
        Inside Dashboard route
    </div>
);
