import React from 'react';

export const HomeComponent = () => (
    <div>
        Inside Home route
    </div>
);
